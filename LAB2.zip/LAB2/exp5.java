package LAB2;

public class exp5 {

    // Variable declared above main (Instance variable)
    int number = 50;

    public static void main(String[] args) {

        // Create object of the class
        exp5 obj = new exp5();

        // Access variable using object
        System.out.println("Value of number = " + obj.number);
    }
}
