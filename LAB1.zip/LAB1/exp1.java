package LAB1;

public class exp1 {
    public static void main(String[] args) {
        String message = "Hello, World!";
        System.out.println(message);
    }
}